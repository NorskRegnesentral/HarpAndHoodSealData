<img src="../R-package/man/figures/NR-logo_utvidet_r32g60b136_small.png" align="right" height="50px"/>

# Seal data to be analysed by the rSPAMM package

#### T. A. Øigård and M. Biuw

# Overview
This folder contains data which can be analyzed by the *rSPAMM* package. For details regarding the the content of the data sets see the instruction [manual](https://github.com/NorskRegnesentral/rSPAMM/blob/master/R-package/README.md) for the package.